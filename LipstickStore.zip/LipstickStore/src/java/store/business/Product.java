/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package store.business;

/**
 *
 * @author liuhonglan
 */

import java.io.Serializable;
import java.text.NumberFormat;
public class Product implements Serializable{
    private String productID;
    private String productName;
    private String productColor;
    private String productImg;
    private double productPrice;
    public Product(){
        productID = "";
        productName = "";
        productColor = "";
        productImg = "";
        productPrice = 0;
    }

    public String getProductID() {
        return productID;
    }

    public void setProductID(String productID) {
        this.productID = productID;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }
    public String getProductColor(){
        return productColor;
    }
    public void setProductColor(String productColor){
        this.productColor = productColor;
    }
    public String getProductImg() {
        return productImg;
    }

    public void setProductImg(String productImg) {
        this.productImg = productImg;
    }

    public double getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }
    public String getPriceCurrencyFormat() {
        NumberFormat currency = NumberFormat.getCurrencyInstance();
        return currency.format(productPrice);
    }
}
