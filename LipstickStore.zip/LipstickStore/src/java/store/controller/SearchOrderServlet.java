/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package store.controller;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import store.data.*;
import store.business.*;
/**
 *
 * @author liuhonglan
 * When a user wants to search his/her history order on index.jsp
 * this servlet deals with that request, searches the products in database and returns result on showHistoryOrder.jsp
 * 
 */
public class SearchOrderServlet extends HttpServlet{
    @Override
    protected void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException{
        String url = "/searchOrder.jsp";
        String action = request.getParameter("action");
        HttpSession session = request.getSession();
        if(action == null)
            url = "/searchOrder.jsp";
        else if(action.equals("searchorder")){
            //User user = (User)session.getAttribute("user");
            //String email = user.getEmail();
            String cardNum = request.getParameter("cardNum");
            ArrayList<Order> orders = OrderIO.getOrder(cardNum);
            session.setAttribute("orders", orders);
            url = "/showHistoryOrder.jsp";
        }
        request.getRequestDispatcher(url).forward(request, response);
    }
}
