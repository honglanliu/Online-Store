/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package store.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import store.data.*;
import store.business.*;
/**
 *
 * @author liuhonglan
 * 
 * When a user checks out, insert order information into table Order_Info
 * Then clear his/her cart
 */
public class CheckoutServlet extends HttpServlet{
    @Override
    protected void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException{
        String url = "/checkout.jsp";
        HttpSession session = request.getSession();
        Cart cart = (Cart)session.getAttribute("cart");
        String action = request.getParameter("action");
        if(action == null)
            url = "/checkout.jsp";
        else if(action.equals("checkout")){
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date = new Date();
            String currentDate = dateFormat.format(date);
            String cardNum = request.getParameter("cardNum");
            String email = request.getParameter("email");
            ArrayList<LineItem> items = cart.getItems();
            for(LineItem item: items){
                String productDes = item.getProduct().getProductName() + "-" + item.getProduct().getProductColor();
                int amount = item.getQuantity();
                int totalPrice = (int)item.getTotal();
                Order order = new Order();
                order.setDate(currentDate);
                order.setCardNum(cardNum);
                order.setEmail(email);
                order.setProductDes(productDes);
                order.setAmount(amount);
                order.setTotalPrice(totalPrice);
                OrderIO.insertOrder(order);
            }
            session.setAttribute("cart", null);
            url = "/confirm.jsp";
        }
        getServletContext().getRequestDispatcher(url).forward(request, response);
    }
}
