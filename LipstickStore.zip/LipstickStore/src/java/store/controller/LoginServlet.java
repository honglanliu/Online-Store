/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package store.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import store.data.*;
import store.business.*;

/**
 *
 * @author liuhonglan
 * 
 * When a user login, compare login email account and password with user information in table:
 */
public class LoginServlet extends HttpServlet{
    @Override
    protected void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException{
        String url = "/login.jsp";
        String action = request.getParameter("action");
        HttpSession session = request.getSession();
        if(action == null)
            action = "login";
        if(action.equals("login"))
            url = "/login.jsp";
        else if(action.equals("check")){
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            //String databaseUrl = "jdbc:sqlite:"+getServletContext().getRealPath("/")+"sqlite.db";
            User user = UserIO.getUser(email);
            String message;
            if(user != null){
                if(user.getPassword().equals(password)){
                    message = "";
                    url = "/success.jsp";
                }
                else{
                    message = "Wrong Password. Please Enter Your Password Again.";
                    url = "/login.jsp";
                }
            }
            else{
                message = "Wrong Email Account. Please Enter Your Email Again.";
                url = "/login.jsp";
            }
            request.setAttribute("message", message);
            session.setAttribute("user", user);
        }
        getServletContext().getRequestDispatcher(url).forward(request, response);
    }
}
