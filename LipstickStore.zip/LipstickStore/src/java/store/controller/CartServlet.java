/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package store.controller;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import store.business.Cart;
import store.business.LineItem;
import store.business.Product;
import store.data.ProductIO;

/**
 *
 * @author liuhonglan
 * 
 * When a user wants to see his/her cart, show products in cart
 * User also can update cart 
 */
public class CartServlet extends HttpServlet{
    @Override
    protected void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException{
        String url = "/index.jsp";
        ServletContext sc = getServletContext();
        String action = request.getParameter("action");
        if(action == null)
            action = "cart";
        //click "Continue Shopping" button, turn to index.jsp
        if(action.equals("shop"))
            url = "/index.jsp";
        else if(action.equals("checkout"))
            url = "/checkout.jsp";
        else if(action.equals("cart")){
            String productID = request.getParameter("productCode");
            String quantityString = request.getParameter("quantity");      
            HttpSession session = request.getSession();
            Cart cart = (Cart)session.getAttribute("cart");
            //if no cart in session, new a cart
            if(cart == null)
                cart = new Cart();
            int quantity;
            //check quantity the user input is a number >= 1 or not. 
            //if not, reset quantity to 1;
            try{
                quantity = Integer.parseInt(quantityString);
                if(quantity < 0)
                    quantity = 1;
            }catch(NumberFormatException e){
                quantity = 1;
            }
            
            //String databaseUrl = "jdbc:sqlite:"+getServletContext().getRealPath("/")+"sqlite.db";
            Product product = ProductIO.getProduct(productID);

            LineItem lineItem = new LineItem();
            lineItem.setProduct(product);
            lineItem.setQuantity(quantity);
            if(quantity > 0){  
                cart.addItem(lineItem);
            }
            else if(quantity == 0){
                cart.removeItem(lineItem);
            }
            session.setAttribute("cart", cart);
            url = "/cart.jsp";
        }
        sc.getRequestDispatcher(url).forward(request, response);
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        String url = "/cart.jsp";
        ServletContext sc = getServletContext();
        sc.getRequestDispatcher(url).forward(request, response);
    }
}
