/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package store.controller;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import store.data.*;
import store.business.*;
/**
 *
 * @author liuhonglan
 * When a user wants to search some products, enter product name on index.jsp
 * this servlet deals with that request, searches the products in database and returns result on showProductSearchResult.jsp
 */
public class SearchProductServlet extends HttpServlet{
    @Override
    protected void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException{
        String url = "/index.jsp";
        String action = request.getParameter("action");
        HttpSession session = request.getSession();
        if(action == null)
            url = "/index.jsp";
        else if(action.equals("searchproduct")){
            String productName = request.getParameter("productName");
            ArrayList<Product> products = ProductIO.searchProducts(productName);
            session.setAttribute("products", products);
            url = "/showProductSearchResult.jsp";
        }
        request.getRequestDispatcher(url).forward(request, response);
    }
    
}
