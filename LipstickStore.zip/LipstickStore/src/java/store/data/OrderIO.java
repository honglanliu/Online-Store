/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package store.data;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import store.business.*;
/**
 *
 * @author liuhonglan
 */
public class OrderIO {
    //When a user wants to see his/her history order:
    public static ArrayList<Order> getOrder(String cardNum){
        ArrayList<Order> orders = new ArrayList<>();
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement pStatement = null;
        ResultSet resultSet = null;
        String query ="select * from Order_Info where Card_Number= ?";
        try{
            pStatement = connection.prepareStatement(query);
            pStatement.setString(1, cardNum);
            resultSet = pStatement.executeQuery();
            while(resultSet.next()){
                //SQLite doesn't have DATE type, just use getString() method to get DATETIME type;
                String oDate = resultSet.getString("Order_Date");
                String email = resultSet.getString("Email");
                String oProductDes = resultSet.getString("Product_Description");
                int oAmount = resultSet.getInt("Amount");
                int oTotal = resultSet.getInt("Total_Price");
                Order order = new Order();
                order.setDate(oDate);
                order.setCardNum(cardNum);
                order.setEmail(email);
                order.setProductDes(oProductDes);
                order.setAmount(oAmount);
                order.setTotalPrice(oTotal);
                orders.add(order);
            }
            return orders;
        }catch(SQLException e){
            System.out.println("SQLException: " + e);
            return null;
        }finally{
            DBUtil.closeResultSet(resultSet);
            DBUtil.closePreparedStatement(pStatement);
            pool.freeConnection(connection);
        }
    }
    
    //When a user checks out, insert his/her order into Order_Info table:
    public static int insertOrder(Order order){
        String date = order.getDate();
        String cardNum = order.getCardNum();
        String email = order.getEmail();
        String productDes = order.getProductDes();
        int amount = order.getAmount();
        int totalPrice = order.getTotalPrice();
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement pStatement = null;
        ResultSet resultSet = null;
        //String query = "insert into Order_Info(Order_Date, Email, Product_Description, Amount, Total_Price) "
                    //+ "values ('" + date + "', " + "'" +email + "', " + "'" + productDes + "', " + "'" + amount + "', " + "'" + totalPrice + "')";
        String query = "insert into Order_Info(Order_Date, Card_Number, Email, Product_Description, Amount, Total_Price) "
                    + "values (?, ?, ?, ?, ?, ?)";
                    
        try{
            pStatement = connection.prepareStatement(query);
            pStatement.setString(1, date);
            pStatement.setString(2, cardNum);
            pStatement.setString(3, email);
            pStatement.setString(4, productDes);
            pStatement.setInt(5, amount);
            pStatement.setInt(6, totalPrice);
            int i = pStatement.executeUpdate();
            return i;
        }catch(SQLException e){
            System.err.println(e);
            return 0;
        }finally{
            DBUtil.closeResultSet(resultSet);
            DBUtil.closePreparedStatement(pStatement);
            pool.freeConnection(connection);
        }
    }
}
