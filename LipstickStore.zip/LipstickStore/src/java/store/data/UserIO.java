/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package store.data;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import store.business.*;
/**
 *
 * @author liuhonglan
 */
public class UserIO {
    //Select user information when a user login, compare login email account and password with those in user information table:
    public static User getUser(String email){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement pStatement = null;
        ResultSet resultSet = null;
        String query ="select * from User_Info where Email = ?";
        try{
            pStatement = connection.prepareStatement(query);
            pStatement.setString(1, email);
            resultSet = pStatement.executeQuery();
            if(resultSet.next()){
                String userId = String.valueOf(resultSet.getInt("UserID"));
                String firstName = resultSet.getString("FirstName");
                String lastName = resultSet.getString("LastName");
                String password = resultSet.getString("Password");
                User user = new User();
                user.setEmail(email);
                user.setFirstName(firstName);
                user.setLastName(lastName);
                user.setUserId(userId);
                user.setPassword(password);
                return user;
            }
            return null;
        }catch(SQLException e){
            System.err.println(e);
            return null;
        }finally{
            DBUtil.closeResultSet(resultSet);
            DBUtil.closePreparedStatement(pStatement);
            pool.freeConnection(connection);
        }
    }
    
    //Insert user information when a new user registers:
    public static int insertUser(User user){
        String firstName = user.getFirstName();
        String lastName = user.getLastName();
        String email = user.getEmail();
        String password = user.getPassword();
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement pStatement = null;
        ResultSet resultSet = null;
        String query = "insert into User_Info(FirstName, LastName, Email, Password) " 
                    + "values(?, ?, ?, ?)";
        try{
            pStatement = connection.prepareStatement(query);
            pStatement.setString(1, firstName);
            pStatement.setString(2, lastName);
            pStatement.setString(3, email);
            pStatement.setString(4, password);
            int i = pStatement.executeUpdate();
            return i;
        }catch(SQLException e){
            System.err.println(e);
            return 0;
        }finally{
            DBUtil.closeResultSet(resultSet);
            DBUtil.closePreparedStatement(pStatement);
            pool.freeConnection(connection);
        }
    }
    
}
