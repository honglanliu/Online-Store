/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package store.data;
import java.sql.*;
/**
 *
 * @author liuhonglan
 * DUBtil() class is for close statement, prepared statement and result set of database;
 */
public class DBUtil {
    public static void closeStatement(Statement s){
        try{
            if(s != null)
                s.close();
        }catch(SQLException e){
            System.out.println("SQLException: " + e);
        }
    }
    
    public static void closePreparedStatement(Statement ps){
        try{
            if(ps != null)
                ps.close();
        }catch(SQLException e){
            System.out.println("SQLException: " + e);
        }
    }
    
    public static void closeResultSet(ResultSet rs){
        try{
            if(rs != null)
                rs.close();
        }catch(SQLException e){
            System.out.println("SQLException: " + e);
        }
    }
}
