/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package store.data;
import java.util.*;
import java.sql.*;

import store.business.*;
/**
 *
 * @author liuhonglan
 */
public class ProductIO {
    //Select product information when the index.jsp displays all the product
    public static Product getProduct(String code){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        Statement statement = null;
        ResultSet resultSet = null;
        String query ="select * from Product";
        try{
            statement = connection.createStatement();
            resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                String productId = String.valueOf(resultSet.getInt("ProductID"));
                if(productId.equals(code)){
                    String pName = resultSet.getString("ProductName");
                    String pColor = resultSet.getString("ProductColor");
                    double pPrice = resultSet.getDouble("ProductPrice");
                    Product p = new Product();
                    p.setProductID(code);
                    p.setProductName(pName);
                    p.setProductColor(pColor);
                    p.setProductPrice(pPrice);
                    return p;
                }
            }
            return null;
        }catch(SQLException e){
            System.err.println(e);
            return null;
        }finally{
            DBUtil.closeResultSet(resultSet);
            DBUtil.closeStatement(statement);
            pool.freeConnection(connection);
        }
    }
    //Select some products when a user wants to search them
    public static ArrayList<Product> searchProducts(String productName){
        ArrayList<Product> products = new ArrayList<>();
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement pStatement = null;
        ResultSet resultSet = null;
        String query ="select * from Product where ProductName like ?";
        try{
            pStatement = connection.prepareStatement(query);
            pStatement.setString(1, "%" + productName + "%");
            resultSet = pStatement.executeQuery();
            while(resultSet.next()){
                String productId = String.valueOf(resultSet.getInt("ProductID"));
                String pName = resultSet.getString("ProductName");
                String pColor = resultSet.getString("ProductColor");
                String pImg = resultSet.getString("ProductImg");
                double pPrice = resultSet.getDouble("ProductPrice");
                Product p = new Product();
                p.setProductID(productId);
                p.setProductName(pName);
                p.setProductColor(pColor);
                p.setProductImg(pImg);
                p.setProductPrice(pPrice);
                products.add(p);
            }
            return products;
        }catch(SQLException e){
            System.err.println(e);
            return null;
        }finally{
            DBUtil.closeResultSet(resultSet);
            DBUtil.closePreparedStatement(pStatement);
            pool.freeConnection(connection);
        }
    }
    
    public static ArrayList<Product> getProducts(){
        ArrayList<Product> products = new ArrayList<>();
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        Statement statement = null;
        ResultSet resultSet = null;
        String query ="select * from Product";
        try{
            statement = connection.createStatement();
            resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                String productId = String.valueOf(resultSet.getInt("ProductID"));
                String pName = resultSet.getString("ProductName");
                String pColor = resultSet.getString("ProductColor");
                String pImg = resultSet.getString("ProductImg");
                double pPrice = resultSet.getDouble("ProductPrice");
                Product p = new Product();
                p.setProductID(productId);
                p.setProductName(pName);
                p.setProductColor(pColor);
                p.setProductImg(pImg);
                p.setProductPrice(pPrice);
                products.add(p);
            }
            return products;
        }catch(SQLException e){
            System.err.println(e);
            return null;
        }finally{
            DBUtil.closeResultSet(resultSet);
            DBUtil.closeStatement(statement);
            pool.freeConnection(connection);
        }
    }
}
